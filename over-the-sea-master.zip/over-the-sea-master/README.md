# over the sea

Proudly presented by [TinyHippo-CG]() & [Bobo]()

浮游在海上的岛屿，潜沉于水下的人。

[🎵 Over the sea, under the water by Cicada](https://cicada.bandcamp.com/track/over-the-sea-under-the-water)



## Usage

```shell
python -m http.server
```

Open `http://localhost:8000`.